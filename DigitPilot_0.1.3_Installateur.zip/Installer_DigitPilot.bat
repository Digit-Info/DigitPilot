@echo off
setlocal
cd /d "%~dp0"
title Assistant d'Installation Digit'Pilot v0.1.3 (Build 2)

:: 1. Verification de l'extraction de l'archive ZIP
if not exist "%~dp0Setup_Files" (
    cls
    echo ====================================================================
    echo   ATTENTION : VOUS DEVEZ EXTRAIRE L'ARCHIVE ZIP AVANT D'INSTALLER !
    echo ====================================================================
    echo.
    echo   Il semble que vous ayez ouvert ce fichier directement dans le ZIP.
    echo.
    echo   Pour reussir l'installation :
    echo   1. Faites un clic droit sur le fichier 'DigitPilot_0.1.3_Build2_Installateur.zip'
    echo   2. Cliquez sur 'Extraire tout' puis sur 'Extraire'
    echo   3. Ouvrez le dossier extrait et relancez 'Installer_DigitPilot.bat'
    echo.
    echo ====================================================================
    pause
    exit /b 1
)

:: 2. Mode silencieux eventuel (-Silent / /S)
if not "%~1"=="" (
    if exist "%~dp0Installer_DigitPilot.ps1" (
        powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installer_DigitPilot.ps1" %*
        exit /b %errorlevel%
    )
)

:: 3. Priorite 1 : Executable natif C# WPF (Setup_DigitPilot.exe)
if exist "%~dp0Setup_DigitPilot.exe" (
    echo [OK] Lancement de l'assistant d'installation moderne Digit'Pilot v0.1.3 (Build 2)...
    start "" "%~dp0Setup_DigitPilot.exe" %*
    exit /b 0
)

:: 4. Priorite 2 : Assistant PowerShell WPF de secours
if exist "%~dp0Installer_DigitPilot.ps1" (
    echo [OK] Lancement du moteur de deploiement PowerShell...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installer_DigitPilot.ps1" %*
    if %errorlevel% neq 0 (
        echo.
        echo [INFO] Fin de l'assistant d'installation.
        pause
    )
    exit /b %errorlevel%
)

cls
echo [ERREUR] Impossible de trouver Setup_DigitPilot.exe ou Installer_DigitPilot.ps1.
pause
exit /b 1
