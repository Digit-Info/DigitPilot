@echo off
setlocal
cd /d "%~dp0"
title Digit'Pilot v0.1.3 (Build 2)
echo ==============================================
echo    DIGIT'PILOT PC UTILITY - v0.1.3 (Build 2)
echo ==============================================
echo.

set "DP_DIR=%~dp0"
if "%DP_DIR:~-1%"=="\" set "DP_DIR=%DP_DIR:~0,-1%"
set "DP_EXE=%DP_DIR%\DigitPilot.exe"

if not exist "%DP_EXE%" (
    echo [ERREUR] DigitPilot.exe est introuvable dans ce dossier.
    pause
    exit /b 1
)

net session >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Execution directe en mode Administrateur...
    start "" /D "%DP_DIR%" "%DP_EXE%"
    exit /b 0
)

echo [INFO] Demande d'elevation Administrateur (UAC)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Start-Process -FilePath $env:DP_EXE -WorkingDirectory $env:DP_DIR -Verb RunAs -ErrorAction Stop } catch { Start-Process -FilePath $env:DP_EXE -WorkingDirectory $env:DP_DIR }"
exit /b 0
