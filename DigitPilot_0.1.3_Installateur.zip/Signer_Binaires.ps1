# Script de signature Authenticode pour Digit'Pilot
$cert = Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert | Where-Object { $_.Subject -match "Digit'Pilot" } | Select-Object -First 1
if (-not $cert) {
    Write-Output "[*] Creation du certificat Code Signing pour Digit'Pilot Technologies..."
    $cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject "CN=Digit'Pilot Technologies" -CertStoreLocation "Cert:\CurrentUser\My" -NotAfter (Get-Date).AddYears(5)
}

$cerExport = Join-Path $PSScriptRoot "DigitPilot_Certificat.cer"
Export-Certificate -Cert $cert -FilePath $cerExport -Force | Out-Null
Write-Output "[+] Certificat exporte : $cerExport"

$targets = @(
    (Join-Path $PSScriptRoot "Setup_DigitPilot.exe"),
    (Join-Path $PSScriptRoot "Setup_Files\DigitPilot.exe"),
    "C:\Users\qbaff\Desktop\apli info pc\2teste\DigitPilot_Dev\bin\Publish_Single\DigitPilot.exe",
    "C:\Users\qbaff\Desktop\apli info pc\2teste\DigitPilot_Client\DigitPilot.exe",
    "C:\Users\qbaff\Desktop\apli info pc\2teste\Distribution_MisesAJour\DigitPilot.exe",
    "C:\Users\qbaff\Desktop\apli info pc\2teste\Distribution_MisesAJour\DigitPilot-Releases\DigitPilot.exe",
    "C:\Users\qbaff\Desktop\apli info pc\DigitPilot_v0.1.3_Build2\DigitPilot_Client\DigitPilot.exe",
    "C:\Users\qbaff\Desktop\apli info pc\DigitPilot_v0.1.3_Build2\DigitPilot_Installateur\Setup_Files\DigitPilot.exe",
    "C:\Users\qbaff\Desktop\apli info pc\DigitPilot_v0.1.3_Build2\DigitPilot_Installateur\Setup_DigitPilot.exe"
)

foreach ($target in $targets) {
    if (Test-Path $target) {
        Write-Output "[*] Signature Authenticode de : $target"
        Set-AuthenticodeSignature -FilePath $target -Certificate $cert -HashAlgorithm SHA256 | Out-Null
        $sig = Get-AuthenticodeSignature -FilePath $target
        Write-Output "    -> Statut : $($sig.Status) | Signataire : $($sig.SignerCertificate.Subject)"
    }
}
Write-Output "[OK] Binaires signes avec succes !"
