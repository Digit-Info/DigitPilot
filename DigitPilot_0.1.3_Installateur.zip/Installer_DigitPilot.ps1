﻿<#
.SYNOPSIS
    Assistant d'Installation Graphique & Silencieux - Digit'Pilot 0.1.3 (Build 3)
.DESCRIPTION
    Installe l'application Digit'Pilot 0.1.3 (Build 3) sur le système, crée les raccourcis bureau et menu démarrer,
    et enregistre le programme dans les paramètres Windows (Ajout/Suppression de programmes) sans aucune altération Defender.
#>

param(
    [switch]$Silent = $false,
    [string]$InstallPath = ""
)

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase -ErrorAction SilentlyContinue

# 1. Verification des droits Administrateur
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin -and [string]::IsNullOrWhiteSpace($InstallPath)) {
    try {
        $argList = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
        if ($Silent) { $argList += " -Silent" }
        if ($InstallPath) { $argList += " -InstallPath `"$InstallPath`"" }
        $elevP = Start-Process powershell.exe -ArgumentList $argList -WorkingDirectory $PSScriptRoot -Verb RunAs -PassThru -Wait -ErrorAction Stop
        exit $elevP.ExitCode
    } catch {
        # Si UAC refusee, installation en mode utilisateur local
        Write-Host "[INFO] Poursuite de l'installation en mode utilisateur."
    }
}

$payloadDir = Join-Path $PSScriptRoot "Setup_Files"
if (-not (Test-Path $payloadDir)) {
    [System.Windows.MessageBox]::Show("Le dossier 'Setup_Files' contenant les fichiers du programme est introuvable.`n`nVeuillez vous assurer d'avoir extrait l'archive ZIP avant de lancer l'installateur.", "Erreur d'installation Digit'Pilot", 0, 16)
    exit 1
}

$defaultInstallDir = if ($InstallPath) { 
    $InstallPath 
} elseif ($isAdmin) { 
    Join-Path ${env:ProgramFiles} "DigitPilot" 
} else { 
    Join-Path ${env:LocalAppData} "DigitPilot" 
}

function Resolve-SafeInstallDir([string]$RawDir) {
    if ([string]::IsNullOrWhiteSpace($RawDir)) { throw "Dossier d'installation invalide." }
    $full = [IO.Path]::GetFullPath($RawDir.Trim()).TrimEnd('\','/')
    $root = [IO.Path]::GetPathRoot($full).TrimEnd('\','/')
    $win = [Environment]::GetFolderPath('Windows').TrimEnd('\','/')
    if ($win -and ($full.Equals($win, [StringComparison]::OrdinalIgnoreCase) -or $full.StartsWith($win + '\', [StringComparison]::OrdinalIgnoreCase))) {
        throw "L'installation dans le répertoire système Windows n'est pas autorisée."
    }
    $sharedRoots = @(
        $root,
        [Environment]::GetFolderPath('ProgramFiles'),
        [Environment]::GetFolderPath('ProgramFilesX86'),
        [Environment]::GetFolderPath('CommonApplicationData'),
        [Environment]::GetFolderPath('UserProfile'),
        [Environment]::GetFolderPath('Desktop'),
        [Environment]::GetFolderPath('CommonDesktopDirectory'),
        [Environment]::GetFolderPath('MyDocuments'),
        [Environment]::GetFolderPath('ApplicationData'),
        [Environment]::GetFolderPath('LocalApplicationData'),
        [IO.Path]::GetTempPath(),
        (Join-Path $env:USERPROFILE 'Downloads')
    )
    foreach ($sr in $sharedRoots) {
        if ([string]::IsNullOrWhiteSpace($sr)) { continue }
        $cleanSr = $sr.TrimEnd('\','/')
        if ($full.Equals($cleanSr, [StringComparison]::OrdinalIgnoreCase)) {
            return Join-Path ($cleanSr + '\') 'DigitPilot'
        }
    }
    return $full
}

# Fonction d'installation interne
function Perform-Installation {
    param(
        [string]$TargetDir,
        [bool]$CreateDesktopShortcut,
        [bool]$CreateStartMenuShortcut,
        [scriptblock]$OnProgress
    )

    $TargetDir = Resolve-SafeInstallDir $TargetDir
    if ((Test-Path -LiteralPath $TargetDir) -and ((Get-Item -LiteralPath $TargetDir -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw "Le dossier de destination est une jonction NTFS ou un lien symbolique non autorisé."
    }

    # 1. Preparation du repertoire
    if ($OnProgress) { & $OnProgress 10 "Préparation du dossier d'installation..." }
    if (-not (Test-Path -LiteralPath $TargetDir)) {
        New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
    }

    # 2. Fermeture preventive d'anciennes instances ciblees
    if ($OnProgress) { & $OnProgress 20 "Fermeture des processus Digit'Pilot et dépendances..." }
    $targetPrefix = $TargetDir.TrimEnd('\') + '\'
    Get-Process -Name "DigitPilot" -ErrorAction SilentlyContinue | Where-Object { 
        try { $_.Path -like "$targetPrefix*" -and $_.Path -like "$TargetDir*" } catch { $false }
    } | Stop-Process -Force -ErrorAction SilentlyContinue
    Get-Process -Name "FanControl" -ErrorAction SilentlyContinue | Where-Object { 
        try { $_.Path -like "$targetPrefix*" -and $_.Path -like "$TargetDir*" } catch { $false }
    } | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 400

    # 3. Copie securisee des fichiers (filtrage strict sans suivi des ReparsePoints)
    if ($OnProgress) { & $OnProgress 40 "Déploiement des binaires et composants système..." }
    function Copy-SafePayload([string]$Src, [string]$Dst) {
        if (-not (Test-Path -LiteralPath $Dst)) { New-Item -ItemType Directory -Path $Dst -Force | Out-Null }
        foreach ($item in Get-ChildItem -LiteralPath $Src -Force) {
            if ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) { continue }
            $targetItem = Join-Path $Dst $item.Name
            if ($item.PSIsContainer) {
                Copy-SafePayload -Src $item.FullName -Dst $targetItem
            } else {
                Copy-Item -LiteralPath $item.FullName -Destination $targetItem -Force
            }
        }
    }
    Copy-SafePayload -Src $payloadDir -Dst $TargetDir

    # 4. Raccourcis
    $wscript = New-Object -ComObject WScript.Shell
    $exePath = Join-Path $TargetDir "DigitPilot.exe"
    $batPath = Join-Path $TargetDir "Lancer_DigitPilot.bat"
    $icoPath = Join-Path $TargetDir "app.ico"
    $targetLauncher = if (Test-Path $batPath) { $batPath } else { $exePath }

    if ($CreateDesktopShortcut) {
        if ($OnProgress) { & $OnProgress 65 "Création du raccourci sur le Bureau..." }
        $desktopFolder = if ($isAdmin) { [System.Environment+SpecialFolder]::CommonDesktopDirectory } else { [System.Environment+SpecialFolder]::Desktop }
        $desktopPath = [System.Environment]::GetFolderPath($desktopFolder)
        if (-not (Test-Path $desktopPath)) { $desktopPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop) }
        $lnkDesktop = Join-Path $desktopPath "Digit'Pilot.lnk"
        
        try {
            $shortcut = $wscript.CreateShortcut($lnkDesktop)
            $shortcut.TargetPath = $targetLauncher
            $shortcut.WorkingDirectory = $TargetDir
            $shortcut.IconLocation = if (Test-Path $icoPath) { "$icoPath,0" } else { "$exePath,0" }
            $shortcut.Description = "Digit'Pilot v0.1.3 - Maintenance, Diagnostic & Performance PC"
            $shortcut.Save()
        } catch { }
    }

    if ($CreateStartMenuShortcut) {
        if ($OnProgress) { & $OnProgress 80 "Ajout au Menu Démarrer de Windows..." }
        $progFolder = if ($isAdmin) { [System.Environment+SpecialFolder]::CommonPrograms } else { [System.Environment+SpecialFolder]::Programs }
        $startMenuRoot = [System.Environment]::GetFolderPath($progFolder)
        if (-not (Test-Path $startMenuRoot)) { $startMenuRoot = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Programs) }
        $startMenuPath = Join-Path $startMenuRoot "Digit'Pilot"
        if (-not (Test-Path $startMenuPath)) { New-Item -ItemType Directory -Path $startMenuPath -Force | Out-Null }
        $lnkStart = Join-Path $startMenuPath "Digit'Pilot.lnk"

        try {
            $shortcut = $wscript.CreateShortcut($lnkStart)
            $shortcut.TargetPath = $targetLauncher
            $shortcut.WorkingDirectory = $TargetDir
            $shortcut.IconLocation = if (Test-Path $icoPath) { "$icoPath,0" } else { "$exePath,0" }
            $shortcut.Description = "Digit'Pilot v0.1.3"
            $shortcut.Save()

            # Raccourci desinstallation
            $lnkUninstall = Join-Path $startMenuPath "Désinstaller Digit'Pilot.lnk"
            $scUninst = $wscript.CreateShortcut($lnkUninstall)
            $scUninst.TargetPath = Join-Path $TargetDir "Desinstaller_DigitPilot.bat"
            $scUninst.WorkingDirectory = $TargetDir
            $scUninst.Description = "Désinstaller Digit'Pilot"
            $scUninst.Save()
        } catch { }
    }

    # 5. Enregistrement Windows "Applications et Fonctionnalités"
    if ($OnProgress) { & $OnProgress 90 "Enregistrement dans le Registre Windows..." }
    $regKey = if ($isAdmin) { "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\DigitPilot" } else { "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\DigitPilot" }
    try {
        if (-not (Test-Path $regKey)) { New-Item -Path $regKey -Force | Out-Null }

        $sizeKb = 0
        Get-ChildItem -Path $TargetDir -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object { $sizeKb += $_.Length }
        $sizeKb = [Math]::Round($sizeKb / 1024)

        Set-ItemProperty -Path $regKey -Name "DisplayName" -Value "Digit'Pilot" -Force
        Set-ItemProperty -Path $regKey -Name "DisplayVersion" -Value "0.1.3" -Force
        Set-ItemProperty -Path $regKey -Name "Publisher" -Value "Digit'Pilot Technologies" -Force
        Set-ItemProperty -Path $regKey -Name "DisplayIcon" -Value $icoPath -Force
        Set-ItemProperty -Path $regKey -Name "InstallLocation" -Value $TargetDir -Force
        Set-ItemProperty -Path $regKey -Name "UninstallString" -Value "`"$TargetDir\Desinstaller_DigitPilot.bat`"" -Force
        Set-ItemProperty -Path $regKey -Name "EstimatedSize" -Value $sizeKb -Force
        Set-ItemProperty -Path $regKey -Name "NoModify" -Value 1 -Force
        Set-ItemProperty -Path $regKey -Name "NoRepair" -Value 1 -Force
        Set-ItemProperty -Path $regKey -Name "Comments" -Value "Digit'Pilot v0.1.3 (Build 3) - Optimisation, Sécurité DPAPI & Diagnostic PC" -Force
        Set-ItemProperty -Path $regKey -Name "URLInfoAbout" -Value "https://github.com/baffert/DigitPilot" -Force
    } catch { }

    # 6. Verification de securite finale (aucune exclusion Defender)
    if ($OnProgress) { & $OnProgress 96 "Verification de l'integrite du deploiement..." }

    if ($OnProgress) { & $OnProgress 100 "Installation achevée avec succès !" }
}

# Mode Silencieux (CLI)
if ($Silent) {
    Perform-Installation -TargetDir $defaultInstallDir -CreateDesktopShortcut $true -CreateStartMenuShortcut $true -OnProgress {
        param($p, $msg) Write-Host "[$p%] $msg"
    }
    exit 0
}

# Mode Graphique Cyber-Glass WPF
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Installation de Digit'Pilot v0.1.3" 
        Height="570" Width="740" 
        WindowStartupLocation="CenterScreen" 
        ResizeMode="NoResize" 
        WindowStyle="None"
        AllowsTransparency="True"
        Background="Transparent" 
        FontFamily="Segoe UI">

    <Border CornerRadius="16" BorderThickness="1.5" Margin="10">
        <Border.BorderBrush>
            <LinearGradientBrush StartPoint="0,0" EndPoint="1,1">
                <GradientStop Color="#00F0FF" Offset="0.0"/>
                <GradientStop Color="#7C3AED" Offset="0.5"/>
                <GradientStop Color="#00FF94" Offset="1.0"/>
            </LinearGradientBrush>
        </Border.BorderBrush>
        <Border.Background>
            <LinearGradientBrush StartPoint="0,0" EndPoint="1,1">
                <GradientStop Color="#0A0713" Offset="0.0"/>
                <GradientStop Color="#120B24" Offset="0.5"/>
                <GradientStop Color="#07050E" Offset="1.0"/>
            </LinearGradientBrush>
        </Border.Background>

        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="Auto"/>
            </Grid.RowDefinitions>

            <!-- HEADER / TITLE BAR -->
            <Border Grid.Row="0" Background="#0F0A1F" CornerRadius="14,14,0,0" Padding="14,10" x:Name="HeaderBar">
                <Grid>
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>

                    <StackPanel Grid.Column="0" Orientation="Horizontal" VerticalAlignment="Center">
                        <Border Background="#1A1233" BorderBrush="#00F0FF" BorderThickness="1" CornerRadius="8" Width="32" Height="32" Margin="0,0,10,0">
                            <TextBlock Text="&#xE945;" FontFamily="Segoe MDL2 Assets" FontSize="16" Foreground="#00F0FF" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <StackPanel VerticalAlignment="Center">
                            <StackPanel Orientation="Horizontal">
                                <TextBlock Text="DIGIT'PILOT" FontSize="14" FontWeight="Bold" Foreground="#FFFFFF"/>
                                <Border Background="#1C1438" BorderBrush="#7C3AED" BorderThickness="1" CornerRadius="4" Padding="5,1" Margin="8,0,0,0" VerticalAlignment="Center">
                                    <TextBlock Text="v0.1.3 Build 3" FontSize="10" FontWeight="SemiBold" Foreground="#00F0FF"/>
                                </Border>
                            </StackPanel>
                            <TextBlock Text="Assistant d'Installation &amp; de Déploiement Officiel" FontSize="10.5" Foreground="#787396"/>
                        </StackPanel>
                    </StackPanel>

                    <Border Grid.Column="1" HorizontalAlignment="Right" Margin="0,0,16,0" Background="#140D2B" BorderBrush="#00FF94" BorderThickness="1" CornerRadius="6" Padding="8,3" VerticalAlignment="Center">
                        <StackPanel Orientation="Horizontal">
                            <TextBlock Text="&#xE72E;" FontFamily="Segoe MDL2 Assets" FontSize="11" Foreground="#00FF94" Margin="0,0,6,0" VerticalAlignment="Center"/>
                            <TextBlock Text="Windows 10/11 Certifié • 64-bit" FontSize="10" FontWeight="SemiBold" Foreground="#00FF94"/>
                        </StackPanel>
                    </Border>

                    <Button x:Name="BtnCloseTop" Grid.Column="2" Content="&#xE8BB;" FontFamily="Segoe MDL2 Assets" FontSize="11" Width="32" Height="28" Background="Transparent" Foreground="#8F8CA8" BorderThickness="0" Cursor="Hand"/>
                </Grid>
            </Border>

            <!-- STEP TRACKER -->
            <Border Grid.Row="1" Background="#0B0817" BorderBrush="#1B1333" BorderThickness="0,0,0,1" Padding="20,10">
                <Grid HorizontalAlignment="Center">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="60"/>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="60"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>

                    <StackPanel Grid.Column="0" Orientation="Horizontal" VerticalAlignment="Center">
                        <Border x:Name="BadgeStep1" Background="#00F0FF" CornerRadius="12" Width="24" Height="24" Margin="0,0,8,0">
                            <TextBlock x:Name="TxtBadgeStep1" Text="1" FontWeight="Bold" FontSize="11" Foreground="#0A0713" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <TextBlock x:Name="LblStep1" Text="Configuration" FontSize="12" FontWeight="SemiBold" Foreground="#00F0FF" VerticalAlignment="Center"/>
                    </StackPanel>

                    <Line Grid.Column="1" X1="10" Y1="12" X2="50" Y2="12" Stroke="#261A45" StrokeThickness="2" VerticalAlignment="Center"/>

                    <StackPanel Grid.Column="2" Orientation="Horizontal" VerticalAlignment="Center">
                        <Border x:Name="BadgeStep2" Background="#1D1538" BorderBrush="#352461" BorderThickness="1" CornerRadius="12" Width="24" Height="24" Margin="0,0,8,0">
                            <TextBlock x:Name="TxtBadgeStep2" Text="2" FontWeight="Bold" FontSize="11" Foreground="#8F8CA8" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <TextBlock x:Name="LblStep2" Text="Déploiement" FontSize="12" FontWeight="SemiBold" Foreground="#8F8CA8" VerticalAlignment="Center"/>
                    </StackPanel>

                    <Line Grid.Column="3" X1="10" Y1="12" X2="50" Y2="12" Stroke="#261A45" StrokeThickness="2" VerticalAlignment="Center"/>

                    <StackPanel Grid.Column="4" Orientation="Horizontal" VerticalAlignment="Center">
                        <Border x:Name="BadgeStep3" Background="#1D1538" BorderBrush="#352461" BorderThickness="1" CornerRadius="12" Width="24" Height="24" Margin="0,0,8,0">
                            <TextBlock x:Name="TxtBadgeStep3" Text="3" FontWeight="Bold" FontSize="11" Foreground="#8F8CA8" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <TextBlock x:Name="LblStep3" Text="Prêt à Piloter" FontSize="12" FontWeight="SemiBold" Foreground="#8F8CA8" VerticalAlignment="Center"/>
                    </StackPanel>
                </Grid>
            </Border>

            <!-- MAIN FORM BODY -->
            <Grid Grid.Row="2" Margin="24,16,24,10">
                <!-- PANEL CONFIG -->
                <Grid x:Name="PanelSetupConfig">
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                    </Grid.RowDefinitions>

                    <Border Grid.Row="0" Background="#110C24" BorderBrush="#251847" BorderThickness="1" CornerRadius="12" Padding="18,14" Margin="0,0,0,14">
                        <StackPanel>
                            <StackPanel Orientation="Horizontal" Margin="0,0,0,8">
                                <TextBlock Text="&#xE8E5;" FontFamily="Segoe MDL2 Assets" FontSize="14" Foreground="#00F0FF" Margin="0,0,8,0" VerticalAlignment="Center"/>
                                <TextBlock Text="Répertoire de destination :" FontSize="13" FontWeight="SemiBold" Foreground="#FFFFFF"/>
                            </StackPanel>
                            <Grid>
                                <Grid.ColumnDefinitions>
                                    <ColumnDefinition Width="*"/>
                                    <ColumnDefinition Width="Auto"/>
                                </Grid.ColumnDefinitions>
                                <Border Grid.Column="0" Background="#191136" BorderBrush="#3D296B" BorderThickness="1" CornerRadius="8" Padding="10,4">
                                    <TextBox x:Name="TxtInstallPath" Height="28" Background="Transparent" Foreground="#FFFFFF" BorderThickness="0" FontSize="12.5" VerticalContentAlignment="Center"/>
                                </Border>
                                <Button x:Name="BtnBrowse" Grid.Column="1" Content="Parcourir..." Width="105" Height="36" Margin="10,0,0,0" Background="#231747" Foreground="#00F0FF" BorderBrush="#50358F" BorderThickness="1" Cursor="Hand" FontWeight="SemiBold"/>
                            </Grid>
                            <TextBlock Text="Espace requis : ~85 Mo  |  Espace disque disponible vérifié" FontSize="11" Foreground="#7A7496" Margin="4,8,0,0"/>
                        </StackPanel>
                    </Border>

                    <Border Grid.Row="1" Background="#110C24" BorderBrush="#251847" BorderThickness="1" CornerRadius="12" Padding="18,14" Margin="0,0,0,14">
                        <StackPanel>
                            <StackPanel Orientation="Horizontal" Margin="0,0,0,8">
                                <TextBlock Text="&#xE713;" FontFamily="Segoe MDL2 Assets" FontSize="14" Foreground="#7C3AED" Margin="0,0,8,0" VerticalAlignment="Center"/>
                                <TextBlock Text="Options d'intégration &amp; sécurité :" FontSize="13" FontWeight="SemiBold" Foreground="#FFFFFF"/>
                            </StackPanel>
                            <CheckBox x:Name="ChkDesktopShortcut" Content="Créer une icône de raccourci sur le Bureau de Windows" Foreground="#D6D3E6" Margin="0,4" IsChecked="True"/>
                            <CheckBox x:Name="ChkStartMenuShortcut" Content="Ajouter Digit'Pilot au Menu Démarrer et dans les Applications" Foreground="#D6D3E6" Margin="0,4" IsChecked="True"/>
                            <CheckBox x:Name="ChkAuthenticodeInfo" Content="Contrôle d'intégrité Authenticode des composants déployés" Foreground="#D6D3E6" Margin="0,4" IsChecked="True" IsEnabled="False"/>
                            <CheckBox x:Name="ChkLaunchAfter" Content="Démarrer automatiquement Digit'Pilot à la fin de l'installation" Foreground="#D6D3E6" Margin="0,4" IsChecked="True"/>
                        </StackPanel>
                    </Border>

                    <Border Grid.Row="2" Background="#0C081A" BorderBrush="#1C1438" BorderThickness="1" CornerRadius="10" Padding="14,10" VerticalAlignment="Top">
                        <StackPanel Orientation="Horizontal">
                            <TextBlock Text="&#xE730;" FontFamily="Segoe MDL2 Assets" FontSize="16" Foreground="#00FF94" Margin="0,0,12,0" VerticalAlignment="Center"/>
                            <StackPanel VerticalAlignment="Center">
                                <TextBlock Text="Installation Propre &amp; Zéro Résidu" FontWeight="SemiBold" FontSize="11.5" Foreground="#D6D3E6"/>
                                <TextBlock Text="Désinstallable à tout moment depuis les Paramètres Windows (Ajout/Suppression de programmes)." FontSize="10.5" Foreground="#787396"/>
                            </StackPanel>
                        </StackPanel>
                    </Border>
                </Grid>

                <!-- PROGRESS PANEL -->
                <Border x:Name="PanelProgress" Background="#110C24" BorderBrush="#251847" BorderThickness="1" CornerRadius="14" Padding="28" VerticalAlignment="Center" Visibility="Collapsed">
                    <StackPanel HorizontalAlignment="Center" Width="540">
                        <TextBlock x:Name="TxtStatus" Text="Déploiement des composants en cours..." FontSize="16" FontWeight="Bold" Foreground="#FFFFFF" HorizontalAlignment="Center" Margin="0,0,0,14"/>
                        <ProgressBar x:Name="PrgInstall" Height="14" Value="0" Maximum="100" Margin="0,0,0,12" Background="#191136" Foreground="#00F0FF" BorderBrush="#352261" BorderThickness="1"/>
                        <TextBlock x:Name="TxtStatusDetail" Text="Veuillez patienter..." FontSize="12" Foreground="#00FF94" HorizontalAlignment="Center"/>
                    </StackPanel>
                </Border>

                <!-- COMPLETE PANEL -->
                <Border x:Name="PanelComplete" Background="#110C24" BorderBrush="#251847" BorderThickness="1" CornerRadius="14" Padding="28" VerticalAlignment="Center" Visibility="Collapsed">
                    <StackPanel HorizontalAlignment="Center" Width="540">
                        <Border Background="#132B22" BorderBrush="#00FF94" BorderThickness="2" CornerRadius="32" Width="64" Height="64" Margin="0,0,0,16" HorizontalAlignment="Center">
                            <TextBlock Text="&#xE73E;" FontFamily="Segoe MDL2 Assets" FontSize="30" Foreground="#00FF94" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <TextBlock Text="INSTALLATION TERMINÉE AVEC SUCCÈS !" FontSize="18" FontWeight="Bold" Foreground="#FFFFFF" HorizontalAlignment="Center" Margin="0,0,0,6"/>
                        <TextBlock Text="Digit'Pilot v0.1.3 (Build 3) est opérationnel et prêt pour votre machine." FontSize="12.5" Foreground="#00FF94" HorizontalAlignment="Center" Margin="0,0,0,16"/>
                        <Border Background="#0C081A" BorderBrush="#1C1438" BorderThickness="1" CornerRadius="10" Padding="16,12">
                            <StackPanel>
                                <TextBlock x:Name="TxtRecapPath" Text="Emplacement : C:\Program Files\DigitPilot" FontSize="11.5" Foreground="#FFFFFF" Margin="0,2"/>
                                <TextBlock Text="Raccourcis Bureau et Menu Démarrer configurés avec succès." FontSize="11" Foreground="#787396" Margin="0,2"/>
                            </StackPanel>
                        </Border>
                    </StackPanel>
                </Border>
            </Grid>

            <!-- FOOTER ACTIONS -->
            <Border Grid.Row="3" Background="#0C081A" BorderBrush="#1A1233" BorderThickness="0,1,0,0" Padding="24,14" CornerRadius="0,0,14,14">
                <Grid>
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>

                    <StackPanel Grid.Column="0" VerticalAlignment="Center">
                        <TextBlock Text="Digit'Pilot v0.1.3 (Build 3) • Architecture Standalone Win-x64" FontSize="11" Foreground="#666082"/>
                        <TextBlock Text="Déploiement certifié sans dépendances tierces requises." FontSize="10" Foreground="#4A4563"/>
                    </StackPanel>

                    <Button x:Name="BtnCancel" Grid.Column="1" Content="Annuler" Width="100" Height="36" Margin="0,0,10,0" Background="#1D1533" BorderBrush="#2E2052" BorderThickness="1" Foreground="#D6D3E6" Cursor="Hand" FontWeight="SemiBold"/>
                    <Button x:Name="BtnInstall" Grid.Column="2" Content="INSTALLER DIGIT'PILOT (v0.1.3)" Width="240" Height="36" Background="#00F0FF" BorderBrush="#00F0FF" Foreground="#0A0713" Cursor="Hand" FontWeight="Bold" FontSize="12"/>
                </Grid>
            </Border>
        </Grid>
    </Border>
</Window>
"@

$reader = (New-Object System.Xml.XmlNodeReader $xaml)
$window = [System.Windows.Markup.XamlReader]::Load($reader)

# Controls
$txtInstallPath = $window.FindName("TxtInstallPath")
$btnBrowse = $window.FindName("BtnBrowse")
$chkDesktop = $window.FindName("ChkDesktopShortcut")
$chkStartMenu = $window.FindName("ChkStartMenuShortcut")

$chkLaunchAfter = $window.FindName("ChkLaunchAfter")
$panelSetupConfig = $window.FindName("PanelSetupConfig")
$panelProgress = $window.FindName("PanelProgress")
$panelComplete = $window.FindName("PanelComplete")
$txtStatus = $window.FindName("TxtStatus")
$txtStatusDetail = $window.FindName("TxtStatusDetail")
$prgInstall = $window.FindName("PrgInstall")
$btnInstall = $window.FindName("BtnInstall")
$btnCancel = $window.FindName("BtnCancel")
$btnCloseTop = $window.FindName("BtnCloseTop")
$headerBar = $window.FindName("HeaderBar")
$badgeStep1 = $window.FindName("BadgeStep1")
$badgeStep2 = $window.FindName("BadgeStep2")
$badgeStep3 = $window.FindName("BadgeStep3")
$lblStep1 = $window.FindName("LblStep1")
$lblStep2 = $window.FindName("LblStep2")
$lblStep3 = $window.FindName("LblStep3")
$txtRecapPath = $window.FindName("TxtRecapPath")

$txtInstallPath.Text = $defaultInstallDir

# Draggable Window
$headerBar.Add_MouseLeftButtonDown({
    if ($_.LeftButton -eq [System.Windows.Input.MouseButtonState]::Pressed) {
        $window.DragMove()
    }
})

$btnCloseTop.Add_Click({
    $window.Close()
})

$btnBrowse.Add_Click({
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Sélectionnez le dossier de destination pour Digit'Pilot :"
    $dialog.SelectedPath = $txtInstallPath.Text
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $sel = $dialog.SelectedPath.Trim(); if (-not $sel.TrimEnd('\','/').EndsWith('DigitPilot', [StringComparison]::OrdinalIgnoreCase)) { $sel = Join-Path $sel 'DigitPilot' }; $txtInstallPath.Text = $sel
    }
})

$btnCancel.Add_Click({
    $window.Close()
})

$script:isInstalled = $false

$btnInstall.Add_Click({
    if ($script:isInstalled) {
        if ($chkLaunchAfter.IsChecked) {
            $targetPath = Resolve-SafeInstallDir $txtInstallPath.Text; $txtInstallPath.Text = $targetPath
            $batLauncher = Join-Path $targetPath "Lancer_DigitPilot.bat"
            if (Test-Path $batLauncher) {
                Start-Process -FilePath $batLauncher -WorkingDirectory $targetPath
            } elseif (Test-Path (Join-Path $targetPath "DigitPilot.exe")) {
                Start-Process -FilePath (Join-Path $targetPath "DigitPilot.exe") -WorkingDirectory $targetPath
            }
        }
        $window.Close()
        return
    }

    $targetPath = Resolve-SafeInstallDir $txtInstallPath.Text; $txtInstallPath.Text = $targetPath
    if ([string]::IsNullOrWhiteSpace($targetPath)) {
        [System.Windows.MessageBox]::Show("Veuillez spécifier un dossier d'installation valide.", "Attention", 0, 48)
        return
    }

    $panelSetupConfig.Visibility = [System.Windows.Visibility]::Collapsed
    $panelProgress.Visibility = [System.Windows.Visibility]::Visible
    $btnInstall.IsEnabled = $false
    $btnCancel.IsEnabled = $false

    # Update Stepper to Step 2
    $badgeStep1.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#1D1538")
    $lblStep1.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#8F8CA8")
    $badgeStep2.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#00F0FF")
    $lblStep2.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#00F0FF")

    $createDesktop = $chkDesktop.IsChecked
    $createStartMenu = $chkStartMenu.IsChecked
    

    $updateProgress = {
        param($p, $msg)
        $prgInstall.Value = $p
        $txtStatusDetail.Text = $msg
        [System.Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Background)
    }

    try {
        & $updateProgress 5 "Démarrage du déploiement..."
        Perform-Installation -TargetDir $targetPath `
                             -CreateDesktopShortcut $createDesktop `
                             -CreateStartMenuShortcut $createStartMenu `
                             -AddDefenderExclusion $addDefender `
                             -OnProgress $updateProgress

        $panelProgress.Visibility = [System.Windows.Visibility]::Collapsed
        $panelComplete.Visibility = [System.Windows.Visibility]::Visible
        $txtRecapPath.Text = "Emplacement : $targetPath"

        # Update Stepper to Step 3
        $badgeStep2.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#1D1538")
        $lblStep2.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#8F8CA8")
        $badgeStep3.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#00FF94")
        $lblStep3.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#00FF94")

        $btnInstall.Content = "LANCER DIGIT'PILOT (v0.1.3)"
        $btnInstall.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#00FF94")
        $btnInstall.BorderBrush = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#00FF94")
        $btnInstall.IsEnabled = $true
        $btnCancel.Content = "Fermer"
        $btnCancel.IsEnabled = $true
        $script:isInstalled = $true
    }
    catch {
        $err = $_.Exception.Message
        $panelProgress.Visibility = [System.Windows.Visibility]::Visible
        $txtStatus.Text = "Erreur lors de l'installation"
        $txtStatus.Foreground = [System.Windows.Media.Brushes]::Red
        $txtStatusDetail.Text = $err
        $btnInstall.Content = "FERMER"
        $btnInstall.IsEnabled = $true
        $btnCancel.IsEnabled = $true
        $script:isInstalled = $true
    }
})

$window.ShowDialog() | Out-Null
