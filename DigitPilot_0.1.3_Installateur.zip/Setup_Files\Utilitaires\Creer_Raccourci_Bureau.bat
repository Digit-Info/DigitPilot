@echo off
setlocal
title Creer Raccourci Bureau - Digit'Pilot
echo ============================================================
echo   CREATION DU RACCOURCI SUR LE BUREAU - DIGIT'PILOT
echo ============================================================
echo.

set "DP_CURR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$curr = $env:DP_CURR.TrimEnd('\'); " ^
  "$rootDir = if (Test-Path -LiteralPath (Join-Path $curr 'DigitPilot.exe')) { $curr } elseif (Test-Path -LiteralPath (Join-Path $curr '..\DigitPilot.exe')) { [IO.Path]::GetFullPath((Join-Path $curr '..')) } else { $curr }; " ^
  "$target = if (Test-Path -LiteralPath (Join-Path $rootDir 'Lancer_DigitPilot.bat')) { Join-Path $rootDir 'Lancer_DigitPilot.bat' } else { Join-Path $rootDir 'DigitPilot.exe' }; " ^
  "$ico = if (Test-Path -LiteralPath (Join-Path $curr 'app.ico')) { (Join-Path $curr 'app.ico') + ',0' } elseif (Test-Path -LiteralPath (Join-Path $rootDir 'app.ico')) { (Join-Path $rootDir 'app.ico') + ',0' } else { (Join-Path $rootDir 'DigitPilot.exe') + ',0' }; " ^
  "$ws = New-Object -ComObject WScript.Shell; " ^
  "$desktop = [System.Environment]::GetFolderPath('Desktop'); " ^
  "$s = $ws.CreateShortcut((Join-Path $desktop 'Digit''Pilot.lnk')); " ^
  "$s.TargetPath = $target; " ^
  "$s.WorkingDirectory = $rootDir; " ^
  "$s.IconLocation = $ico; " ^
  "$s.Description = 'Digit''Pilot v0.1.3 (Build 2) - PC Cleaner & Utility'; " ^
  "$s.Save();"

echo [OK] Le raccourci "Digit'Pilot" a ete cree sur votre Bureau avec succes !
ping 127.0.0.1 -n 3 >nul
