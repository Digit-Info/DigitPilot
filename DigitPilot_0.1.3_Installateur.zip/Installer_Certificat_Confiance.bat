@echo off
setlocal
cd /d "%~dp0"
title Digit'Pilot - Installation du Certificat de Confiance Windows

:: Verification Elevation Administrateur
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Elevation des privileges Administrateur requise...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

cls
echo ========================================================================
echo       DIGIT'PILOT - INSTALLATION DU CERTIFICAT DE SECURITE WINDOWS
echo ========================================================================
echo.
echo Ce script ajoute l'identite numerique officielle de Digit'Pilot Technologies
echo aux autorites et editeurs approuves de ce PC Windows.
echo.
echo Cela permet :
echo  - De supprimer les alertes SmartScreen ("Editeur inconnu")
echo  - De valider la signature numerique Authenticode (SHA-256)
echo  - D'autoriser l'execution en toute fluidite et sans blocage
echo.

if not exist "%~dp0DigitPilot_Certificat.cer" (
    echo [ERREUR] Le fichier 'DigitPilot_Certificat.cer' est introuvable dans ce dossier.
    echo.
    pause
    exit /b 1
)

echo [1/2] Enregistrement dans les Editeurs Approuves Windows...
certutil.exe -addstore -f "TrustedPublisher" "%~dp0DigitPilot_Certificat.cer" >nul 2>&1
certutil.exe -user -addstore "TrustedPublisher" "%~dp0DigitPilot_Certificat.cer" >nul 2>&1

echo [2/2] Enregistrement dans les Autorites Racines de Confiance...
certutil.exe -addstore -f "Root" "%~dp0DigitPilot_Certificat.cer" >nul 2>&1

echo.
echo ========================================================================
echo   [SUCCES] CERTIFICAT DIGIT'PILOT TECHNOLOGIES VALIDE AVEC SUCCES !
echo   Vous pouvez desormais lancer l'installateur sans aucun avertissement.
echo ========================================================================
echo.
pause
exit /b 0
