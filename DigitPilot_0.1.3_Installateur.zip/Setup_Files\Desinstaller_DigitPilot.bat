@echo off
setlocal
chcp 1252 >nul 2>&1
title Desinstallation de Digit'Pilot
echo ===================================================
echo             DESINSTALLATION DE DIGIT'PILOT
echo ===================================================
echo.

set "INSTALL_DIR=%~dp0"
if "%INSTALL_DIR:~-1%"=="\" set "INSTALL_DIR=%INSTALL_DIR:~0,-1%"
set "DP_SELF=%~f0"
set "DP_ARGS=%*"

:: Garde-fou immediat : ne jamais supprimer un dossier source/portable DigitPilot_Client ou Setup_Files
for %%I in ("%INSTALL_DIR%") do set "LEAF_DIR=%%~nxI"
if /i "%LEAF_DIR%"=="DigitPilot_Client" (
    echo [SECURITE] Ce script est execute depuis le dossier portable "%LEAF_DIR%".
    echo            Pour proteger vos fichiers sources/portables, la suppression est bloquee.
    echo            Utilisez le desinstallateur situe dans le dossier installe ^(ex: C:\Program Files\DigitPilot^).
    if /i not "%~1"=="/silent" if /i not "%~1"=="/s" if /i not "%~1"=="-Silent" pause
    exit /b 1
)
if /i "%LEAF_DIR%"=="Setup_Files" (
    echo [SECURITE] Execution bloquee depuis le dossier de charge utile "%LEAF_DIR%".
    if /i not "%~1"=="/silent" if /i not "%~1"=="/s" if /i not "%~1"=="-Silent" pause
    exit /b 1
)

:: Verification des privileges administrateur (requise uniquement si le dossier cible necessite une elevation, ex: Program Files)
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$dir = [IO.Path]::GetFullPath($env:INSTALL_DIR); $pf = [Environment]::GetFolderPath('ProgramFiles'); $pf86 = [Environment]::GetFolderPath('ProgramFilesX86'); if (($pf -and $dir.StartsWith($pf, [StringComparison]::OrdinalIgnoreCase)) -or ($pf86 -and $dir.StartsWith($pf86, [StringComparison]::OrdinalIgnoreCase))) { exit 10 }; try { $probe = Join-Path $dir ('.dp_uninst_probe_' + [Guid]::NewGuid().ToString('N')); [IO.File]::WriteAllText($probe, 'ok'); [IO.File]::Delete($probe); exit 0 } catch { exit 10 }"
    if errorlevel 10 (
        echo [INFO] Elevation des privileges Administrateur requise pour "%INSTALL_DIR%"...
        powershell -NoProfile -ExecutionPolicy Bypass -Command "$cmdArgs = '/c \"\"' + $env:DP_SELF + '\" ' + $env:DP_ARGS + '\"'; $p = Start-Process -FilePath 'cmd.exe' -ArgumentList $cmdArgs -Verb RunAs -PassThru -Wait; exit $p.ExitCode"
        exit /b %errorlevel%
    )
)

:: Gestion du mode silencieux
if /i "%~1"=="/silent" goto DO_UNINSTALL
if /i "%~1"=="/s" goto DO_UNINSTALL
if /i "%~1"=="/y" goto DO_UNINSTALL
if /i "%~1"=="-Silent" goto DO_UNINSTALL

echo Dossier cible : %INSTALL_DIR%
echo Voulez-vous vraiment desinstaller Digit'Pilot de cet ordinateur ?
echo (Tous les fichiers du programme installe et ses raccourcis seront supprimes).
echo.
set /p CONFIRM="Confirmer la desinstallation (O/N) ? [O] : "
if /i "%CONFIRM%"=="N" (
    echo [INFO] Desinstallation annulee par l'utilisateur.
    ping 127.0.0.1 -n 2 >nul
    exit /b 0
)

:DO_UNINSTALL
echo.
echo [1/4] Arret cible des processus Digit'Pilot en cours...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$dir = [IO.Path]::GetFullPath($env:INSTALL_DIR).TrimEnd('\') + '\'; Get-Process -Name 'DigitPilot','FanControl' -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -and $_.Path.StartsWith($dir, [StringComparison]::OrdinalIgnoreCase) } catch { $false } } | Stop-Process -Force -ErrorAction SilentlyContinue" >nul 2>&1
ping 127.0.0.1 -n 2 >nul

echo [2/4] Suppression des raccourcis...
set "DESKTOP_LNK=%PUBLIC%\Desktop\Digit'Pilot.lnk"
if exist "%DESKTOP_LNK%" del /f /q "%DESKTOP_LNK%" >nul 2>&1

set "USER_DESKTOP_LNK=%USERPROFILE%\Desktop\Digit'Pilot.lnk"
if exist "%USER_DESKTOP_LNK%" del /f /q "%USER_DESKTOP_LNK%" >nul 2>&1

set "START_MENU_DIR=%PROGRAMDATA%\Microsoft\Windows\Start Menu\Programs\Digit'Pilot"
if exist "%START_MENU_DIR%" rd /s /q "%START_MENU_DIR%" >nul 2>&1

set "USER_START_MENU_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Digit'Pilot"
if exist "%USER_START_MENU_DIR%" rd /s /q "%USER_START_MENU_DIR%" >nul 2>&1

echo [3/4] Suppression de l'enregistrement Windows (Applications et fonctionnalites)...
reg delete "HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall\DigitPilot" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\DigitPilot" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "DigitPilot" /f >nul 2>&1

echo [4/4] Suppression securisee des fichiers du programme...
cd /d "%TEMP%"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$dir = [IO.Path]::GetFullPath($env:INSTALL_DIR).TrimEnd('\'); " ^
  "$self = [IO.Path]::GetFullPath($env:DP_SELF); " ^
  "$root = [IO.Path]::GetPathRoot($dir).TrimEnd('\'); " ^
  "$win = [Environment]::GetFolderPath('Windows').TrimEnd('\'); " ^
  "$blocked = @($root, $win, [Environment]::GetFolderPath('ProgramFiles').TrimEnd('\'), [Environment]::GetFolderPath('ProgramFilesX86').TrimEnd('\'), [Environment]::GetFolderPath('CommonApplicationData').TrimEnd('\'), [Environment]::GetFolderPath('UserProfile').TrimEnd('\'), [Environment]::GetFolderPath('Desktop').TrimEnd('\'), [Environment]::GetFolderPath('CommonDesktopDirectory').TrimEnd('\'), [Environment]::GetFolderPath('MyDocuments').TrimEnd('\'), [Environment]::GetFolderPath('ApplicationData').TrimEnd('\'), [Environment]::GetFolderPath('LocalApplicationData').TrimEnd('\'), [IO.Path]::GetTempPath().TrimEnd('\'), (Join-Path $env:USERPROFILE 'Downloads')); " ^
  "if (($blocked | Where-Object { $_ -and $dir.Equals($_, [StringComparison]::OrdinalIgnoreCase) }) -or $dir.StartsWith($win + '\', [StringComparison]::OrdinalIgnoreCase)) { exit 2 }; " ^
  "function Remove-SafeTree([string]$p) { foreach ($item in Get-ChildItem -LiteralPath $p -Force -ErrorAction SilentlyContinue) { if ($item.FullName.Equals($self, [StringComparison]::OrdinalIgnoreCase)) { continue }; if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { if ($item.PSIsContainer) { [IO.Directory]::Delete($item.FullName, $false) } else { [IO.File]::Delete($item.FullName) }; continue }; if ($item.PSIsContainer) { Remove-SafeTree $item.FullName; [IO.Directory]::Delete($item.FullName, $false) } else { Remove-Item -LiteralPath $item.FullName -Force -ErrorAction SilentlyContinue } } }; " ^
  "if (Test-Path -LiteralPath $dir) { Remove-SafeTree $dir }" >nul 2>&1

echo.
echo ===================================================
echo     Digit'Pilot a ete desinstalle avec succes !
echo ===================================================
start "" /b powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command "Start-Sleep -Milliseconds 500; $s = $env:DP_SELF; $d = $env:INSTALL_DIR; if ($s -and (Test-Path -LiteralPath $s)) { Remove-Item -LiteralPath $s -Force -ErrorAction SilentlyContinue }; if ($d -and (Test-Path -LiteralPath $d) -and @(Get-ChildItem -LiteralPath $d -Force -ErrorAction SilentlyContinue).Count -eq 0) { [IO.Directory]::Delete($d, $false) }" >nul 2>&1 & exit /b 0
